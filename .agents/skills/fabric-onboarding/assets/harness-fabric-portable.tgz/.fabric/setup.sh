#!/bin/sh
set -eu

fabric_project=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd -P)
fabric_bundle="$fabric_project/.fabric/harness-fabric.tgz"
fabric_runtime="$fabric_project/.fabric/runtime"
fabric_skill="$fabric_project/.agents/skills/fabric-onboarding/SKILL.md"

if [ ! -f "$fabric_bundle" ]; then
  echo "缺少本地 Fabric 包：$fabric_bundle" >&2
  exit 1
fi
if ! command -v node >/dev/null 2>&1 || ! node -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 22 ? 0 : 1)'; then
  echo '需要 Node.js 22+；请先在宿主安装。' >&2
  exit 1
fi
if ! command -v npm >/dev/null 2>&1; then
  echo '需要 npm；请先在宿主安装。' >&2
  exit 1
fi

mkdir -p "$fabric_project/.fabric"
transaction=$(mktemp -d "$fabric_project/.fabric/setup.XXXXXX")
candidate="$transaction/runtime"
backup=""
swapped=0
onboarding_created=0
role_conflicts=""

rollback() {
  status=$?; trap - EXIT HUP INT TERM
  if [ "$status" -ne 0 ] && [ "$swapped" -eq 1 ]; then
    for role in main coordinator manager worker reviewer; do
      target="$fabric_project/.agents/skills/fabric-$role/SKILL.md"
      if [ -f "$transaction/role-new-$role" ] && [ -n "$backup" ]; then
        tmp="$target.setup-rollback.$$"
        cp "$backup/node_modules/harness-fabric/.agents/skills/fabric-$role/SKILL.md" "$tmp" && mv "$tmp" "$target" || true
      fi
    done
    if [ "$onboarding_created" -eq 1 ]; then
      rm -f "$fabric_skill"
    fi
    rm -rf "$fabric_runtime"
    if [ -n "$backup" ] && [ -d "$backup" ]; then mv "$backup" "$fabric_runtime"; fi
  fi
  rm -rf "$transaction"
  exit "$status"
}
trap rollback EXIT HUP INT TERM

npm install --prefix "$candidate" --cache "$fabric_project/.fabric/npm-cache" --offline --ignore-scripts --no-audit --no-fund --no-save --no-package-lock "$fabric_bundle"
fabric_source="$candidate/node_modules/harness-fabric/.agents/skills/fabric-onboarding/SKILL.md"
if [ ! -f "$fabric_source" ]; then echo '便携包缺少 onboarding Skill；旧 Runtime 保持不变。' >&2; exit 1; fi
if [ -e "$fabric_skill" ] || [ -L "$fabric_skill" ]; then
  if [ -L "$fabric_skill" ] || ! cmp -s "$fabric_source" "$fabric_skill"; then
    echo "已有不同内容的 onboarding Skill；请先通过 Hub 更新或明确解决冲突：$fabric_skill" >&2; exit 1
  fi
fi

if [ -d "$fabric_runtime/node_modules/harness-fabric/.agents/skills" ]; then
  for role in main coordinator manager worker reviewer; do
    target="$fabric_project/.agents/skills/fabric-$role/SKILL.md"
    old="$fabric_runtime/node_modules/harness-fabric/.agents/skills/fabric-$role/SKILL.md"
    new="$candidate/node_modules/harness-fabric/.agents/skills/fabric-$role/SKILL.md"
    if [ -f "$target" ] && [ ! -L "$target" ] && [ -f "$old" ] && [ -f "$new" ]; then
      if cmp -s "$old" "$target"; then
        if ! cmp -s "$new" "$target"; then
          cp "$new" "$transaction/role-new-$role"
        fi
      else role_conflicts="$role_conflicts $role"; fi
    fi
  done
fi

if [ -d "$fabric_runtime" ]; then
  backup="$fabric_project/.fabric/runtime.backup.$(date +%Y%m%d%H%M%S).$$"
  mv "$fabric_runtime" "$backup"
  swapped=1
fi
if ! mv "$candidate" "$fabric_runtime"; then
  echo '无法切换候选 Runtime；已恢复升级前状态。' >&2; exit 1
fi
swapped=1
fabric_source="$fabric_runtime/node_modules/harness-fabric/.agents/skills/fabric-onboarding/SKILL.md"

if [ ! -e "$fabric_skill" ]; then
  mkdir -p "$(dirname -- "$fabric_skill")"
  tmp="$fabric_skill.setup-$$"
  cp "$fabric_source" "$tmp" && mv "$tmp" "$fabric_skill" || exit 1
  onboarding_created=1
fi
for role in main coordinator manager worker reviewer; do
  target="$fabric_project/.agents/skills/fabric-$role/SKILL.md"
  if [ -f "$transaction/role-new-$role" ]; then
    tmp="$target.setup-$$"
    cp "$transaction/role-new-$role" "$tmp" && mv "$tmp" "$target" || exit 1
  fi
done

echo "Fabric CLI：$fabric_runtime/node_modules/.bin/fabric"; echo "Onboarding Skill：$fabric_skill"
if [ -n "$backup" ]; then echo "旧 Runtime 备份（可回退）：$backup"; fi; if [ -n "$role_conflicts" ]; then echo "保留自定义 Fabric Role Skill：$role_conflicts"; fi
echo '在本项目启动 Codex，要求它使用 fabric-onboarding 完成初始化；setup 不修改 AGENTS.md 或项目依赖。'
swapped=0
trap - EXIT HUP INT TERM
rm -rf "$transaction"
